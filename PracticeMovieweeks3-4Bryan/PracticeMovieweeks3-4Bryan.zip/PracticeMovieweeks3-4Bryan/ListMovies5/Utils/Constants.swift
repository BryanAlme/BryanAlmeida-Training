//
//  Constants.swift
//  ListMovies5
//
//  Created by Bryan Andres  Almeida Flores on 03/05/2022.
//

import Foundation

class Constants {
    static var username: String = "username"
    static var movies: String = "movies"
}

